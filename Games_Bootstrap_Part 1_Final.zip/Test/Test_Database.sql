-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1:3307
-- Generation Time: Dec 15, 2025 at 05:17 PM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `games`
--

-- --------------------------------------------------------

--
-- Table structure for table `accounts`
--

CREATE TABLE `accounts` (
  `acc_id` int(6) NOT NULL,
  `username` varchar(25) NOT NULL,
  `password` varchar(25) NOT NULL,
  `email` varchar(320) NOT NULL,
  `country` enum('USA','Canada','Mexico','China','Japan','South Korea','Indonesia','Malaysia','Singapore','UK','Ireland','France','Spain','Germany','Italy','Russia','South Africa') NOT NULL DEFAULT 'USA',
  `birthdate` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `accounts`
--

INSERT INTO `accounts` (`acc_id`, `username`, `password`, `email`, `country`, `birthdate`) VALUES
(1, 'uib', '12345', 'uib@gmail.com', 'Indonesia', '2025-08-06'),
(2, 'joltec', '260900', 'joltec@gmail.com', 'Indonesia', '2000-06-01'),
(6, '2020070586@student.pppkpe', 'ggg', '20200700586@student.pppkpetra.sch.id', 'UK', '2025-12-04'),
(7, 'hhh', 'hhh', 'geygye@gmail.com', 'Indonesia', '2025-12-03'),
(8, 'yyy', 'yyy', 'geygye@gmail.com', 'UK', '2025-12-25');

-- --------------------------------------------------------

--
-- Table structure for table `game`
--

CREATE TABLE `game` (
  `game_id` int(6) UNSIGNED NOT NULL,
  `game_title` varchar(100) NOT NULL,
  `dev` varchar(100) NOT NULL,
  `genre` varchar(255) NOT NULL,
  `rel_date` date NOT NULL DEFAULT current_timestamp(),
  `desc` varchar(255) NOT NULL,
  `price` int(255) UNSIGNED NOT NULL,
  `points` int(250) UNSIGNED NOT NULL,
  `control_support` varchar(255) NOT NULL DEFAULT 'None'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `game`
--

INSERT INTO `game` (`game_id`, `game_title`, `dev`, `genre`, `rel_date`, `desc`, `price`, `points`, `control_support`) VALUES
(1, 'Terra Nil', 'Free Lives, Clockwork Acorn', 'Casual, Indie', '2023-03-28', 'Terra Nil is an intricate environmental strategy game about transforming a barren wasteland into a thriving, balanced ecosystem. Bring life back to a lifeless world by purifying soil, cleaning oceans, planting trees, and reintroducing wildlife, then leave', 10, 50, 'None'),
(2, 'Monster Hunter Wilds', 'CAPCOM Co., Ltd.', 'Action, Adventure, RPG', '2025-02-28', 'The unbridled force of nature runs wild and relentlessly, with environments transforming drastically from one moment to the next. This is a story of monsters and humans, and their struggles to coexist in a world of duality.', 70, 250, 'XBox Controllers, DualShock Controllers, DualSense Controllers, Steam Input API');

-- --------------------------------------------------------

--
-- Table structure for table `pict`
--

CREATE TABLE `pict` (
  `pict_id` int(11) NOT NULL,
  `pict_title` varchar(50) NOT NULL,
  `pict_desc` varchar(300) DEFAULT NULL,
  `pict_pict` varchar(50) NOT NULL,
  `dev` varchar(255) NOT NULL,
  `genre` varchar(200) NOT NULL,
  `rel_date` date NOT NULL,
  `price` decimal(10,2) UNSIGNED NOT NULL,
  `point` int(255) UNSIGNED NOT NULL,
  `control_support` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `pict`
--

INSERT INTO `pict` (`pict_id`, `pict_title`, `pict_desc`, `pict_pict`, `dev`, `genre`, `rel_date`, `price`, `point`, `control_support`) VALUES
(1, 'Terra Nil', 'Terra Nil is an intricate environmental strategy game that challenges players to transform a barren wasteland into a thriving, balanced ecosystem. Bring life back to a lifeless world by purifying soil, cleaning oceans, planting trees, and reintroducing wildlife, then leave.', 'terranil.jpg', '	\r\nFree Lives, Clockwork Acorn', 'Casual, Indie', '2023-03-28', 10.00, 50, 'None'),
(2, 'Monster Hunter Wilds', 'The unbridled force of nature runs wild and relentlessly, with environments transforming drastically from one moment to the next. This is a story of monsters and humans, and their struggles to coexist in a world of duality.', 'mhwilds.jpg', 'CAPCOM Co., Ltd.', 'Action, Adventure, RPG', '2025-02-28', 70.00, 250, 'XBox Controllers, DualShock Controllers, DualSense Controllers, Steam Input API'),
(3, 'Hollow Knight: Silksong', 'Discover a vast, haunted kingdom in Hollow Knight: Silksong! Explore, fight, and survive as you ascend to the peak of a land ruled by silk and song.', 'silksongtitle.webp', 'Team Cherry', 'Action, Adventure, Metroidvania', '2025-09-04', 20.00, 20, 'XBox Controller, DualSense Edge Controller');

-- --------------------------------------------------------

--
-- Table structure for table `playersonline`
--

CREATE TABLE `playersonline` (
  `playnumb` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `pointstore_items`
--

CREATE TABLE `pointstore_items` (
  `item_id` int(11) NOT NULL,
  `title` varchar(100) NOT NULL,
  `origin` varchar(255) NOT NULL,
  `type` varchar(100) NOT NULL,
  `desc` text NOT NULL,
  `point_price` int(11) NOT NULL,
  `image` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `pointstore_items`
--

INSERT INTO `pointstore_items` (`item_id`, `title`, `origin`, `type`, `desc`, `point_price`, `image`) VALUES
(1, 'Green Plains', 'Joyvault', 'Background', 'The wide-open plains and a sky full of possibility. A reminder to keep exploring.', 5, 'plains.jpg'),
(2, 'Sad Coffee', 'Joyvault', 'Emoticon', 'Espresso Depresso', 5, 'sadcoffee.webp'),
(3, 'God of War', 'God of War: Ragnarok', 'Avatar', 'Útlægr Guð.\r\nSmán föður.\r\nVon móður.\r\nÞraut barnsins.', 20, 'kratos_avatar.webp');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `accounts`
--
ALTER TABLE `accounts`
  ADD PRIMARY KEY (`acc_id`);

--
-- Indexes for table `game`
--
ALTER TABLE `game`
  ADD PRIMARY KEY (`game_id`);

--
-- Indexes for table `pict`
--
ALTER TABLE `pict`
  ADD PRIMARY KEY (`pict_id`);

--
-- Indexes for table `pointstore_items`
--
ALTER TABLE `pointstore_items`
  ADD PRIMARY KEY (`item_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `accounts`
--
ALTER TABLE `accounts`
  MODIFY `acc_id` int(6) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `game`
--
ALTER TABLE `game`
  MODIFY `game_id` int(6) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `pict`
--
ALTER TABLE `pict`
  MODIFY `pict_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `pointstore_items`
--
ALTER TABLE `pointstore_items`
  MODIFY `item_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
